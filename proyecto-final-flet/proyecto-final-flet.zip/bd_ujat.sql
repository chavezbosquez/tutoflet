CREATE TABLE bd_ujat;

CREATE TABLE division(
    clave TEXT NOT NULL UNIQUE PRIMARY KEY,
    nombre TEXT NOT NULL,
    ubicacion TEXT
)